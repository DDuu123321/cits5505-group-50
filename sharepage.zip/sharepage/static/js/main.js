console.log("main.js is loaded!");
function loadMyReports() {
  $.get('/api/my-reports', function (data) {
    const container = $('#mySharesList');
    container.empty();
    if (data.length === 0) {
      container.append('<div class="text-muted">No shared reports yet.</div>');
    } else {
      data.forEach(r => {
        container.append(`
          <div class="list-group-item">
            <strong>${r.title}</strong><br>
            <small>${r.created_at}</small>
            <p>${r.description}</p>
          </div>
        `);
      });
    }
  });
}
console.log("Sending:", payload)
$(document).ready(function () {
  loadMyReports();

  $('#submitReport').on('click', function () {
    const title = $('#reportTitle').val();
    const description = $('#reportDescription').val();
    const startDate = $('#startDate').val();
    const endDate = $('#endDate').val();
    const expiryDate = $('#expiryDate').val();
    const permission = $('input[name="permissionLevel"]:checked').attr('id');

    const subjects = [];
    $('#createReportModal input[type="checkbox"]:checked').each(function () {
      subjects.push($(this).next('label').text().trim());
    });

    const emails = [];
    $('#createReportModal .badge').each(function () {
      const email = $(this).text().trim().split(' ')[0];
      if (email) emails.push(email);
    });

    const payload = {
      title,
      description,
      startDate,
      endDate,
      expiryDate,
      permission,
      subjects,
      emails
    };

    $.ajax({
      type: 'POST',
      url: '/share/create',
      contentType: 'application/json',
      data: JSON.stringify(payload),
      success: function (res) {
        if (res.success) {
          $('#createReportModal').modal('hide');
          $('#createReportModal').find('input, textarea').val('');
          $('#createReportModal input[type="checkbox"]').prop('checked', false);
          loadMyReports();
        } else {
          alert('Failed to save report: ' + res.error);
        }
      },
      error: function (xhr) {
        alert('Error: ' + xhr.responseText);
      }
    });
  });
});
